### 2.4.1
Thunderstore relese

### 2.4.3
More info in README and configs

### 2.5.1
WardIsLove fixes. Fixes in holes

### 2.7.0
ArcaneWard support;
Works with Valheim 1.0.221.4;
Better code parallelism;
Doesn't kick players during reset

### 2.7.1
Removed discord webhook to pass thunderstore moderation
